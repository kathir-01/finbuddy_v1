// Data Models and Storage Helpers
const STORAGE_KEYS = {
  USERS: 'finbuddy_users',
  CURRENT_USER: 'finbuddy_current_user',
  EXPENSES: 'finbuddy_expenses_',
  GOAL: 'finbuddy_goal_'
};

// Utilities
function getUsers() {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
}

function saveUsers(users) {
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
}

function getCurrentUser() {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.CURRENT_USER));
}

function setCurrentUser(user) {
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
}

function getUserExpenses() {
  const user = getCurrentUser();
  if (!user) return [];
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.EXPENSES + user.email) || '[]');
}

function saveUserExpenses(expenses) {
  const user = getCurrentUser();
  if (user) {
    localStorage.setItem(STORAGE_KEYS.EXPENSES + user.email, JSON.stringify(expenses));
  }
}

function getUserGoal() {
  const user = getCurrentUser();
  if (!user) return 0;
  return parseFloat(localStorage.getItem(STORAGE_KEYS.GOAL + user.email) || '0');
}

function saveUserGoal(goal) {
  const user = getCurrentUser();
  if (user) {
    localStorage.setItem(STORAGE_KEYS.GOAL + user.email, goal.toString());
  }
}

function requireAuth() {
  const user = getCurrentUser();
  const path = window.location.pathname;
  
  // If not logged in and not on login/signup page, redirect to login
  if (!user && !path.includes('index.html') && !path.includes('signup.html') && !path.endsWith('/') && !path.endsWith('FINBUDDY')) {
    window.location.href = 'index.html';
  }
  
  // If logged in and on login/signup page, redirect to dashboard
  if (user && (path.includes('index.html') || path.includes('signup.html') || path.endsWith('/') || path.endsWith('FINBUDDY'))) {
    window.location.href = 'dashboard.html';
  }
}

// Global initialization
document.addEventListener('DOMContentLoaded', () => {
  requireAuth();
  
  const path = window.location.pathname;
  
  // Route logic based on current HTML file
  if (path.includes('signup.html')) {
    initSignup();
  } else if (path.includes('index.html') || path.endsWith('/') || path.endsWith('FINBUDDY')) {
    initLogin();
  } else if (path.includes('dashboard.html')) {
    initDashboard();
  } else if (path.includes('add-expense.html')) {
    initAddExpense();
  } else if (path.includes('history.html')) {
    initHistory();
  }

  // Common UI logic like Logout
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
      window.location.href = 'index.html';
    });
  }
});


// Initialization Functions

function initSignup() {
  const form = document.getElementById('signupForm');
  const errorMsg = document.getElementById('signupError');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value.toLowerCase();
    const password = document.getElementById('password').value;

    const users = getUsers();
    if (users.find(u => u.email === email)) {
      errorMsg.style.display = 'block';
      return;
    }

    const newUser = { name, email, password };
    users.push(newUser);
    saveUsers(users);
    
    // Auto login
    setCurrentUser(newUser);
    window.location.href = 'dashboard.html';
  });
}

function initLogin() {
  const form = document.getElementById('loginForm');
  if(!form) return; 
  const errorMsg = document.getElementById('loginError');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value.toLowerCase();
    const password = document.getElementById('password').value;

    const users = getUsers();
    const user = users.find(u => u.email === email && u.password === password);

    if (user) {
      setCurrentUser(user);
      window.location.href = 'dashboard.html';
    } else {
      errorMsg.style.display = 'block';
    }
  });
}

function initDashboard() {
  const user = getCurrentUser();
  if(!user) return;
  
  document.getElementById('userNameDisplay').textContent = user.name;
  
  const expenses = getUserExpenses();
  let goal = getUserGoal();
  
  // Total Expenses
  const totalExpense = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  document.getElementById('totalExpenseDisplay').textContent = `₹${totalExpense}`;
  
  // Goal Progress
  const goalForm = document.getElementById('setGoalForm');
  const goalInput = document.getElementById('goalAmount');
  
  if (goal > 0) {
    updateGoalDisplay(totalExpense, goal);
    goalInput.value = goal;
  }
  
  goalForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const newGoal = parseFloat(goalInput.value);
    if(newGoal > 0){
      saveUserGoal(newGoal);
      updateGoalDisplay(totalExpense, newGoal);
    }
  });

  // Recent Transactions (Last 3)
  const recentList = document.getElementById('recentExpensesList');
  const sortedExpenses = [...expenses].sort((a,b) => new Date(b.date) - new Date(a.date));
  const recent3 = sortedExpenses.slice(0, 3);
  
  if (recent3.length === 0) {
    recentList.innerHTML = '<li style="text-align:center; padding: 1rem; color: #666;">No expenses yet.</li>';
  } else {
    recent3.forEach(exp => {
      const li = document.createElement('li');
      li.className = 'expense-item';
      li.innerHTML = `
        <div class="expense-info">
          <div class="category">${exp.category}</div>
          <div class="date">${exp.date}</div>
        </div>
        <div class="expense-amount">₹${exp.amount}</div>
      `;
      recentList.appendChild(li);
    });
  }
  
  // Gamification (Badge for >= 3 expenses)
  if (expenses.length >= 3) {
    document.getElementById('gamificationBadge').style.display = 'inline-block';
  }
  
  // AI insight text
  generateInsight(expenses);
  
  // Chart.js rendering
  renderChart(expenses);
}

function updateGoalDisplay(total, goal) {
  const progressText = document.getElementById('savingsProgressText');
  const percentageText = document.getElementById('savingsPercentage');
  const progressBar = document.getElementById('savingsProgressBar');
  
  let percentage = (total / goal) * 100;
  if(percentage > 100) percentage = 100;
  
  progressText.textContent = `₹${total} / ₹${goal}`;
  percentageText.textContent = `${percentage.toFixed(1)}%`;
  progressBar.style.width = `${percentage}%`;
  
  // Gamification: If they stayed under the threshold? Actually, a generic tracker.
  // If we assume the goal is a budget.
  if (percentage >= 100) {
    progressBar.style.backgroundColor = '#d32f2f'; // Red (Danger)
  } else {
    progressBar.style.backgroundColor = 'var(--primary-color)';
  }
}

function generateInsight(expenses) {
  const insightText = document.getElementById('aiInsightText');
  if (expenses.length === 0) {
    return;
  }
  
  const categoryTotals = {};
  expenses.forEach(exp => {
    categoryTotals[exp.category] = (categoryTotals[exp.category] || 0) + exp.amount;
  });
  
  let maxCategory = '';
  let maxAmount = 0;
  
  for (const cat in categoryTotals) {
    if (categoryTotals[cat] > maxAmount) {
      maxAmount = categoryTotals[cat];
      maxCategory = cat;
    }
  }
  
  if (maxCategory) {
    insightText.innerHTML = `💡 <strong>AI Insight:</strong> You are spending the most on <strong>${maxCategory}</strong> (₹${maxAmount}). Try to reduce to increase savings!`;
  }
}

function renderChart(expenses) {
  const ctx = document.getElementById('expenseChart');
  if (!ctx) return;
  
  if (expenses.length === 0) {
    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['No Data'],
        datasets: [{
          data: [1],
          backgroundColor: ['#e0e0e0'],
          borderWidth: 0
        }]
      },
      options: { 
        responsive: true, 
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: { enabled: false }
        }
      }
    });
    return;
  }
  
  const categoryTotals = {};
  expenses.forEach(exp => {
    categoryTotals[exp.category] = (categoryTotals[exp.category] || 0) + exp.amount;
  });
  
  const labels = Object.keys(categoryTotals);
  const data = Object.values(categoryTotals);
  const colors = [
    '#4caf50', // Green
    '#2196f3', // Blue
    '#ff9800', // Orange
    '#9c27b0', // Purple
    '#607d8b'  // Grey
  ];
  
  new Chart(ctx, {
    type: 'pie', // Explicitly pie chart requested
    data: {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: colors.slice(0, labels.length),
        borderWidth: 1,
        borderColor: '#fff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'right',
          labels: {
            font: { family: 'Inter', size: 12 }
          }
        }
      }
    }
  });
}

function initAddExpense() {
  const form = document.getElementById('addExpenseForm');
  const categorySelect = document.getElementById('category');
  const otherCategoryGroup = document.getElementById('otherCategoryGroup');
  const otherCategoryInput = document.getElementById('otherCategory');

  document.getElementById('date').valueAsDate = new Date(); // set default date to today
  
  categorySelect.addEventListener('change', (e) => {
    if (e.target.value === 'Others 📦') {
      otherCategoryGroup.style.display = 'block';
      otherCategoryInput.required = true;
    } else {
      otherCategoryGroup.style.display = 'none';
      otherCategoryInput.required = false;
    }
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const amount = parseFloat(document.getElementById('amount').value);
    let category = document.getElementById('category').value;
    const date = document.getElementById('date').value;
    
    if (category === 'Others 📦') {
      category = document.getElementById('otherCategory').value;
    }

    const expenses = getUserExpenses();
    expenses.push({
      id: Date.now(),
      amount,
      category,
      date
    });
    
    saveUserExpenses(expenses);
    window.location.href = 'dashboard.html';
  });
}

function initHistory() {
  const tbody = document.getElementById('historyTableBody');
  const noDataMsg = document.getElementById('noDataMessage');
  const table = document.getElementById('historyTable');
  const clearBtn = document.getElementById('clearHistoryBtn');
  
  const expenses = getUserExpenses();
  
  if (expenses.length === 0) {
    table.style.display = 'none';
    noDataMsg.style.display = 'block';
    clearBtn.style.display = 'none';
    return;
  }
  
  const sortedExpenses = [...expenses].sort((a,b) => new Date(b.date) - new Date(a.date));
  
  sortedExpenses.forEach(exp => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${exp.date}</td>
      <td><strong>${exp.category}</strong></td>
      <td style="color: var(--danger); font-weight: bold;">₹${exp.amount}</td>
      <td><button class="btn-delete" data-id="${exp.id}" style="padding: 0.25rem 0.5rem; background-color: var(--danger); color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 0.8rem;">Delete</button></td>
    `;
    tbody.appendChild(tr);
  });
  
  tbody.addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-delete')) {
      if(confirm('Are you sure you want to delete this specific expense?')) {
        const id = parseInt(e.target.getAttribute('data-id'));
        let allExpenses = getUserExpenses();
        allExpenses = allExpenses.filter(exp => exp.id !== id);
        saveUserExpenses(allExpenses);
        window.location.reload();
      }
    }
  });
  
  clearBtn.addEventListener('click', () => {
    if(confirm('Are you sure you want to clear all expense history?')) {
      saveUserExpenses([]);
      window.location.reload();
    }
  });
}
